import cloudinary from "cloudinary";

cloudinary.config({
  cloud_name: "dprrpqa54",
  api_key: "682516998839431",
  api_secret: "z4N0GmEGfX5fiUQzmTX10Sohbpw",
});
export default cloudinary;
